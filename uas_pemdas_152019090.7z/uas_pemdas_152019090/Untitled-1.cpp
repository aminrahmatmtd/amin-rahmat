#include <iostream>
#include <string>
#include <math.h>

#define S 50

using namespace std;

int main() {
 int n, i, j,j2, pangkat1,pangkat2, sigma1,sigma2,sigma3, sigma4;
 float x1, x2, y1, y2, a,b;
 
 cout<< "Berapa Banyak Data?";
 cin>> n;

 cout<< "Masukan Data!" << endl;

 if (n = 2) {
    cout << "x[1] = "; cin >> x1;
    cout << "y[1] = "; cin >> y1;
    cout << "x[2] = "; cin >> x2;
    cout << "y[2] = "; cin >> y2;

 }
 cout<< endl;
 j = x1*y1;
 j2 = x2*y2;
 cout << "Nilai xy = "<< j << endl;
 cout << "Nilai xy = "<< j2 << endl;

pangkat1=pow(x1,x1);
cout << "\n" << x1<<" pangkat "<< x1 <<" = " << pangkat1;
pangkat2=pow(x2,x2);
cout << "\n" << x2<<" pangkat "<< x2 <<" = " << pangkat2 << endl;

cout << endl;
sigma1 = x1+x2;
cout << "Hasil Sigma X adalah " << sigma1 << endl;
sigma2 = y1=y2;
cout << "Hasil Sigma Y adalah " << sigma2 << endl;
sigma3 = j+j2;
cout << "Hasil Sigma Y adalah " << sigma2 << endl;
}